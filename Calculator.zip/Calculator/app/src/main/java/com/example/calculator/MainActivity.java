package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    // Declare UI element
    private TextView displayTextView;

    // Variables to hold the state of the calculator
    private double valueOne = Double.NaN;
    private char currentOperation = ' '; // '+', '-', '*', '/'
    private boolean isNewInput = true; // Tracks if the next button press starts a new number

    // Formatter to remove unnecessary .0 from whole numbers
    private static final DecimalFormat decimalFormat = new DecimalFormat("0.##########");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize display
        displayTextView = findViewById(R.id.displayTextView);

        // IDs for all buttons
        int[] allButtonIds = {
                R.id.button0, R.id.button1, R.id.button2, R.id.button3,
                R.id.button4, R.id.button5, R.id.button6, R.id.button7,
                R.id.button8, R.id.button9, R.id.buttonDot,
                R.id.buttonAdd, R.id.buttonSubtract, R.id.buttonMultiply,
                R.id.buttonDivide, R.id.buttonEquals, R.id.buttonClear
        };

        // Set the single click listener for all buttons
        for (int id : allButtonIds) {
            findViewById(id).setOnClickListener(this);
        }

        // Initialize display to "0"
        displayTextView.setText("0");
    }

    // Single click handler for all buttons
    @Override
    public void onClick(View v) {
        Button b = (Button) v;
        String buttonText = b.getText().toString();
        int id = v.getId();

        // Check if the button is a number/dot
        if (id == R.id.button0 || id == R.id.button1 || id == R.id.button2 || id == R.id.button3 ||
                id == R.id.button4 || id == R.id.button5 || id == R.id.button6 || id == R.id.button7 ||
                id == R.id.button8 || id == R.id.button9 || id == R.id.buttonDot) {

            handleNumberInput(buttonText);

        } else if (id == R.id.buttonAdd || id == R.id.buttonSubtract ||
                id == R.id.buttonMultiply || id == R.id.buttonDivide) {

            handleOperation(buttonText.charAt(0));

        } else if (id == R.id.buttonEquals) {

            handleEquals();

        } else if (id == R.id.buttonClear) {

            handleClear();
        }
    }

    // --- Helper Methods for Logic ---

    private void handleNumberInput(String number) {
        String currentDisplay = displayTextView.getText().toString();

        if (isNewInput) {
            // Replace "0" or the previous result
            if (number.equals(".")) {
                displayTextView.setText("0.");
            } else {
                displayTextView.setText(number);
            }
            isNewInput = false;
        } else {
            // Append the number or dot
            if (number.equals(".")) {
                // Prevent multiple dots
                if (!currentDisplay.contains(".")) {
                    displayTextView.append(number);
                }
            } else if (currentDisplay.equals("0")) {
                // Replace initial '0' with the first number
                displayTextView.setText(number);
            } else {
                displayTextView.append(number);
            }
        }
    }

    private void handleOperation(char operation) {
        if (Double.isNaN(valueOne)) {
            // This is the first number input. Store it.
            try {
                valueOne = Double.parseDouble(displayTextView.getText().toString());
            } catch (NumberFormatException e) {
                // Should not happen if number input is handled correctly
                valueOne = 0;
            }
        } else if (!isNewInput) {
            // This is the second or subsequent operator. Calculate intermediate result.
            double valueTwo = 0;
            try {
                valueTwo = Double.parseDouble(displayTextView.getText().toString());
            } catch (NumberFormatException e) {
                // Ignore if display is invalid
            }

            valueOne = calculate(valueOne, valueTwo, currentOperation);

            // Handle division by zero error
            if (Double.isNaN(valueOne)) {
                handleClear();
                return;
            }

            // Display the intermediate result
            displayTextView.setText(decimalFormat.format(valueOne));
        }

        // Set the new operation and flag for new input
        currentOperation = operation;
        isNewInput = true;
    }

    private void handleEquals() {
        if (!Double.isNaN(valueOne) && currentOperation != ' ' && !isNewInput) {
            double valueTwo = 0;
            try {
                // Get the second number from the display
                valueTwo = Double.parseDouble(displayTextView.getText().toString());
            } catch (NumberFormatException e) {
                // Ignore if display is invalid
            }

            // Calculate the final result
            double result = calculate(valueOne, valueTwo, currentOperation);

            // Handle division by zero error
            if (Double.isNaN(result)) {
                handleClear();
                return;
            }

            // Display the result
            displayTextView.setText(decimalFormat.format(result));

            // Reset state for next calculation
            valueOne = result; // Use result as the start of the next calculation
            currentOperation = ' '; // Reset operation
            isNewInput = true;
        }
    }

    private void handleClear() {
        valueOne = Double.NaN;
        currentOperation = ' ';
        isNewInput = true;
        displayTextView.setText("0");
        Toast.makeText(this, "Cleared", Toast.LENGTH_SHORT).show();
    }

    private double calculate(double num1, double num2, char operation) {
        switch (operation) {
            case '+':
                return num1 + num2;
            case '-':
                return num1 - num2;
            case '*':
                return num1 * num2;
            case '/':
                if (num2 == 0) {
                    Toast.makeText(this, "Cannot divide by zero", Toast.LENGTH_LONG).show();
                    return Double.NaN; // Indicate error
                }
                return num1 / num2;
            default:
                return num2; // If no operation, return the second number (current display)
        }
    }
}